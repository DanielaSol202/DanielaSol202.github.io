import React from 'react';
import FloatingNumbers from '../components/FloatingNumbers';
import StarDecoration from '../components/StarDecoration';

const AboutSection: React.FC = () => {
  return (
    <section className="min-h-screen bg-gradient-to-br from-white to-beige flex items-center justify-center px-6 py-20 relative">
      <FloatingNumbers />
      
      <div className="container mx-auto max-w-4xl relative z-10">
        <div className="text-center space-y-12">
          {/* Header */}
          <div className="space-y-4 relative">
            <StarDecoration className="absolute -top-12 left-1/4 text-pink animate-pulse" size="lg" />
            
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-navy">
              Sobre Mí
            </h2>
            
            <div className="w-24 h-1 bg-pink mx-auto rounded-full"></div>
          </div>

          {/* Main Content */}
          <div className="relative">
            <StarDecoration className="absolute -top-8 -right-12 text-navy/20" size="md" />
            <StarDecoration className="absolute bottom-4 -left-16 text-pink/30" size="sm" />
            
            <div className="bg-white/70 backdrop-blur-sm p-8 md:p-12 rounded-3xl shadow-lg">
              <p className="text-xl md:text-2xl lg:text-3xl text-navy leading-relaxed font-light">
                Apasionada por los <span className="font-semibold text-pink">datos</span> y la{' '}
                <span className="font-semibold text-pink">tecnología</span>, con base en{' '}
                <span className="font-semibold text-pink">Python</span>. Me encanta transformar grandes volúmenes de datos en{' '}
                <span className="font-semibold text-pink">visualizaciones claras y útiles</span>.
                <br />
                <br />
                Disfruto trabajar en <span className="font-semibold text-pink">equipo</span>, comunicar ideas de forma sencilla y{' '}
                <span className="font-semibold text-pink">aprender siempre algo nuevo</span> en entornos dinámicos y desafiantes.
              </p>
            </div>
          </div>

          {/* Stats or Highlights */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16">
            {[
              { number: '1+', label: 'Años de Experiencia' },
              { number: '3+', label: 'Proyectos Completados' },
              { number: '100%', label: 'Dedicación' },
              { number: '∞', label: 'Ganas de Aprender' }
            ].map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="text-3xl md:text-4xl font-bold text-pink group-hover:scale-110 transition-transform duration-300">
                  {stat.number}
                </div>
                <div className="text-sm text-navy/70 mt-2">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;