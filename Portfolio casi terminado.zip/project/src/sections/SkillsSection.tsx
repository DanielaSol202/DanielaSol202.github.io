import React from 'react';
import SkillIcon from '../components/SkillIcon';
import StarDecoration from '../components/StarDecoration';

const SkillsSection: React.FC = () => {
  const skills = [
    { name: 'Python', icon: '🐍', level: 90 },
    { name: 'Pandas', icon: '🐼', level: 85 },
    { name: 'SQL', icon: '💾', level: 75 },
    { name: 'Power BI', icon: '📈', level: 80 },
    { name: 'Power Apps', icon: '⚡', level: 70 },
    { name: 'Excel', icon: '📋', level: 85 },
    { name: 'Tableau', icon: '🎯', level: 70 },
    { name: 'Databricks', icon: '🧱', level: 75 },
    { name: 'Machine Learning', icon: '🤖', level: 70 }
  ];

  const softSkills = [
    'Trabajo en Equipo',
    'Comunicación Efectiva',
    'Resolución de Problemas',
    'Pensamiento Analítico',
    'Adaptabilidad',
    'Creatividad'
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-beige to-white px-6 py-20">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="text-center space-y-8 mb-16 relative">
          <StarDecoration className="absolute -top-8 left-1/4 text-pink animate-pulse" size="lg" />
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-navy">
            Mis Habilidades
          </h2>
          
          <div className="w-24 h-1 bg-pink mx-auto rounded-full"></div>
          
          <p className="text-xl text-navy/70 max-w-2xl mx-auto">
            Herramientas y tecnologías que uso para transformar datos en insights valiosos
          </p>
        </div>

        {/* Technical Skills */}
        <div className="space-y-12">
          <div className="relative">
            <StarDecoration className="absolute -top-4 -right-8 text-navy/20" size="md" />
            
            <h3 className="text-2xl font-bold text-navy mb-8 text-center">
              Habilidades Técnicas
            </h3>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
              {skills.map((skill, index) => (
                <SkillIcon
                  key={index}
                  name={skill.name}
                  icon={skill.icon}
                  level={skill.level}
                />
              ))}
            </div>
          </div>

          {/* Soft Skills */}
          <div className="relative">
            <StarDecoration className="absolute bottom-8 -left-8 text-pink/30" size="sm" />
            
            <h3 className="text-2xl font-bold text-navy mb-8 text-center">
              Soft Skills
            </h3>
            
            <div className="bg-white/70 backdrop-blur-sm p-8 rounded-3xl shadow-lg">
              <div className="flex flex-wrap justify-center gap-4">
                {softSkills.map((skill, index) => (
                  <span
                    key={index}
                    className="bg-gradient-to-r from-pink to-pink/80 text-white px-6 py-3 rounded-full font-semibold text-sm hover:scale-105 transition-transform duration-300 cursor-default"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;