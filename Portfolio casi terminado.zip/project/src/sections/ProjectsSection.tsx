import React from 'react';
import ProjectCard from '../components/ProjectCard';
import FloatingNumbers from '../components/FloatingNumbers';
import StarDecoration from '../components/StarDecoration';

const ProjectsSection: React.FC = () => {
  const projects = [
    {
      title: 'Dashboard de Ventas Interactivo',
      description: 'Plataforma web para visualización de datos de ventas en tiempo real con gráficos interactivos y filtros dinámicos.',
      technologies: ['Python', 'Pandas', 'Plotly', 'Streamlit'],
      image: '📊',
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      title: 'Sistema de Análisis de Clientes',
      description: 'Aplicación web para segmentación de clientes y análisis de comportamiento usando machine learning.',
      technologies: ['Python', 'Scikit-learn', 'Flask', 'SQL'],
      image: '👥',
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      title: 'Portal de Reportes Automatizados',
      description: 'Sistema web que genera reportes automáticos y los envía por email con visualizaciones personalizadas.',
      technologies: ['Python', 'Power BI', 'SQL Server', 'HTML/CSS'],
      image: '📈',
      liveUrl: '#',
      githubUrl: '#'
    }
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-white to-beige px-6 py-20 relative">
      <FloatingNumbers />
      
      <div className="container mx-auto max-w-7xl relative z-10">
        {/* Header */}
        <div className="text-center space-y-8 mb-16 relative">
          <StarDecoration className="absolute -top-8 left-1/4 text-pink animate-pulse" size="lg" />
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-navy">
            Mis Proyectos
          </h2>
          
          <div className="w-24 h-1 bg-pink mx-auto rounded-full"></div>
          
          <p className="text-xl text-navy/70 max-w-2xl mx-auto">
            Proyectos web que demuestran mi experiencia en análisis de datos y desarrollo
          </p>
        </div>

        {/* Projects Grid */}
        <div className="relative">
          <StarDecoration className="absolute -top-4 -right-8 text-navy/20" size="md" />
          <StarDecoration className="absolute bottom-10 -left-8 text-pink/30" size="sm" />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <ProjectCard
                key={index}
                title={project.title}
                description={project.description}
                technologies={project.technologies}
                image={project.image}
                liveUrl={project.liveUrl}
                githubUrl={project.githubUrl}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;