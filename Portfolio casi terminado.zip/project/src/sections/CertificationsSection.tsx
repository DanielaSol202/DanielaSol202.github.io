import React from 'react';
import CertificationCard from '../components/CertificationCard';
import FloatingNumbers from '../components/FloatingNumbers';
import StarDecoration from '../components/StarDecoration';

const CertificationsSection: React.FC = () => {
  const certifications = [
    {
      title: 'Certificado Talento Tech',
      organization: 'Talento Tech',
      year: '',
      icon: '🎓',
      driveUrl: 'https://drive.google.com/drive/folders/1Xj52fCaqOtGKuVRb1L2kWsjqS3baei7G?usp=sharing'
    },
    {
      title: 'Certificado Santander',
      organization: 'Banco Santander',
      year: '',
      icon: '🏦',
      driveUrl: 'https://drive.google.com/drive/folders/1Xj52fCaqOtGKuVRb1L2kWsjqS3baei7G?usp=sharing'
    },
    {
      title: 'Certificado Pescar',
      organization: 'Fundación Pescar',
      year: '',
      icon: '🐟',
      driveUrl: 'https://drive.google.com/drive/folders/1Xj52fCaqOtGKuVRb1L2kWsjqS3baei7G?usp=sharing'
    }
  ];

  return (
    <section className="min-h-screen bg-gradient-to-br from-beige to-white px-6 py-20 relative">
      <FloatingNumbers />
      
      <div className="container mx-auto max-w-6xl relative z-10">
        {/* Header */}
        <div className="text-center space-y-8 mb-16 relative">
          <StarDecoration className="absolute -top-8 left-1/4 text-pink animate-pulse" size="lg" />
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-navy">
            Certificaciones
          </h2>
          
          <div className="w-24 h-1 bg-pink mx-auto rounded-full"></div>
          
          <p className="text-xl text-navy/70 max-w-2xl mx-auto">
            Certificaciones que respaldan mi formación y experiencia profesional
          </p>
        </div>

        {/* Certifications Grid */}
        <div className="relative">
          <StarDecoration className="absolute -top-4 -right-8 text-navy/20" size="md" />
          <StarDecoration className="absolute bottom-10 -left-8 text-pink/30" size="sm" />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {certifications.map((cert, index) => (
              <CertificationCard
                key={index}
                title={cert.title}
                organization={cert.organization}
                year={cert.year}
                icon={cert.icon}
                driveUrl={cert.driveUrl}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CertificationsSection;