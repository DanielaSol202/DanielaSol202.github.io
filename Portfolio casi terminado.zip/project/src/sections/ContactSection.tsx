import React from 'react';
import ContactIcon from '../components/ContactIcon';
import FloatingNumbers from '../components/FloatingNumbers';
import StarDecoration from '../components/StarDecoration';

const ContactSection: React.FC = () => {
  return (
    <section className="min-h-screen bg-gradient-to-br from-white to-beige px-6 py-20 relative">
      <FloatingNumbers />
      
      <div className="container mx-auto max-w-4xl relative z-10">
        {/* Header */}
        <div className="text-center space-y-8 mb-16 relative">
          <StarDecoration className="absolute -top-8 left-1/4 text-pink animate-pulse" size="lg" />
          
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-navy">
            Contáctame
          </h2>
          
          <div className="w-24 h-1 bg-pink mx-auto rounded-full"></div>
          
        </div>

        {/* Contact Info */}
        <div className="relative">
          <StarDecoration className="absolute -top-4 -right-8 text-navy/20" size="md" />
          <StarDecoration className="absolute bottom-10 -left-8 text-pink/30" size="sm" />
          
          <div className="bg-white/70 backdrop-blur-sm p-8 md:p-12 rounded-3xl shadow-lg">
            <div className="grid md:grid-cols-2 gap-6">
              <ContactIcon
                type="address"
                value="CABA, Buenos Aires"
              />
              <ContactIcon
                type="phone"
                value="+54 9 11 6793-4793"
                href="tel:+5491167934793"
              />
              <ContactIcon
                type="email"
                value="danielallusco1@gmail.com"
                href="mailto:danielallusco1@gmail.com"
              />
              <ContactIcon
                type="linkedin"
                value="linkedin.com/in/danielallusco"
                href="https://www.linkedin.com/in/danielallusco"
              />
            </div>
            
            <div className="mt-6 flex justify-center">
              <ContactIcon
                type="github"
                value="DanielaSol202"
                href="https://github.com/DanielaSol202"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;