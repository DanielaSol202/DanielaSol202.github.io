import React from 'react';
import ContactIcon from '../components/ContactIcon';
import StarDecoration from '../components/StarDecoration';

const HomeSection: React.FC = () => {
  return (
    <section className="min-h-screen bg-gradient-to-br from-beige to-white flex items-center justify-center px-6 py-20">
      <div className="container mx-auto max-w-6xl">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Side - Introduction */}
          <div className="space-y-8 relative">
            <StarDecoration className="absolute -top-8 -left-4 text-pink animate-pulse" size="lg" />
            
            <div className="space-y-4">
              <div className="inline-block bg-pink text-white px-4 py-2 rounded-full text-sm font-semibold" style={{visibility: 'hidden'}}>
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-navy leading-tight">
                ¡Hola, soy{' '}
                <span className="text-pink">Daniela Sol</span>
                <br />
                <span className="text-pink">Llusco Gonzales!</span>
              </h1>
              
              <p className="text-xl text-navy/80 leading-relaxed">
                Data Analyst apasionada por transformar datos en insights valiosos
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
            </div>
          </div>

          {/* Right Side - Welcome Message */}
          <div className="space-y-8 relative flex items-center justify-center">
            <StarDecoration className="absolute -top-4 -right-4 text-navy/20" size="md" />
            <StarDecoration className="absolute bottom-10 -left-8 text-pink/30" size="sm" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HomeSection;