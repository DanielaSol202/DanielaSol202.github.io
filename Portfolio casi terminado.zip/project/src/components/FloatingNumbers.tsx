import React, { useEffect, useState } from 'react';

const FloatingNumbers: React.FC = () => {
  const [numbers, setNumbers] = useState<Array<{
    id: number;
    value: string;
    x: number;
    y: number;
    delay: number;
  }>>([]);

  useEffect(() => {
    const dataNumbers = ['01', '10', '11', '00', '101', '010', '110', '001', '111', '100'];
    const newNumbers = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      value: dataNumbers[Math.floor(Math.random() * dataNumbers.length)],
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 5
    }));
    setNumbers(newNumbers);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30">
      {numbers.map((number) => (
        <div
          key={number.id}
          className="absolute text-navy font-mono text-lg font-bold animate-float"
          style={{
            left: `${number.x}%`,
            top: `${number.y}%`,
            animationDelay: `${number.delay}s`,
            animationDuration: '4s'
          }}
        >
          {number.value}
        </div>
      ))}
    </div>
  );
};

export default FloatingNumbers;