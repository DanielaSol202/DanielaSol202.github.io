import React from 'react';
import { MapPin, Phone, Mail, Linkedin, Github } from 'lucide-react';

interface ContactIconProps {
  type: 'address' | 'phone' | 'email' | 'linkedin' | 'github';
  value: string;
  href?: string;
}

const ContactIcon: React.FC<ContactIconProps> = ({ type, value, href }) => {
  const icons = {
    address: MapPin,
    phone: Phone,
    email: Mail,
    linkedin: Linkedin,
    github: Github
  };

  const Icon = icons[type];
  
  const content = (
    <div className="flex items-center space-x-3 p-3 bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 hover:scale-105 group">
      <div className="text-pink group-hover:text-navy transition-colors duration-300">
        <Icon size={20} />
      </div>
      <span className="text-navy text-sm font-medium">{value}</span>
    </div>
  );

  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className="block">
        {content}
      </a>
    );
  }

  return content;
};

export default ContactIcon;