import React from 'react';
import { ExternalLink } from 'lucide-react';

interface CertificationCardProps {
  title: string;
  organization: string;
  year: string;
  icon: string;
  driveUrl: string;
}

const CertificationCard: React.FC<CertificationCardProps> = ({
  title,
  organization,
  year,
  icon,
  driveUrl
}) => {
  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 hover:scale-105 group">
      <div className="text-center space-y-4">
        <div className="text-5xl mb-4">{icon}</div>
        
        <h3 className="text-xl font-bold text-navy">{title}</h3>
        <p className="text-navy/70 font-medium">{organization}</p>
        {year && <p className="text-pink font-semibold">{year}</p>}
        
        <a
          href={driveUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center space-x-2 bg-pink text-white px-4 py-2 rounded-full hover:bg-pink/80 transition-all duration-300 group-hover:scale-105"
        >
          <span className="text-sm font-medium">Ver Certificado</span>
          <ExternalLink size={16} />
        </a>
      </div>
    </div>
  );
};

export default CertificationCard;