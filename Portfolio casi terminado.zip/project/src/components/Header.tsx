import React from 'react';
import { Menu, X } from 'lucide-react';

interface HeaderProps {
  currentSection: string;
  setCurrentSection: (section: string) => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
}

const Header: React.FC<HeaderProps> = ({
  currentSection,
  setCurrentSection,
  isMobileMenuOpen,
  setIsMobileMenuOpen
}) => {
  const sections = [
    { id: 'home', label: 'Inicio' },
    { id: 'about', label: 'Sobre Mí' },
    { id: 'skills', label: 'Habilidades' },
    { id: 'projects', label: 'Mis Proyectos' },
    { id: 'certifications', label: 'Certificaciones' },
    { id: 'contact', label: 'Contáctame' }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 shadow-sm">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-navy">
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-8">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => setCurrentSection(section.id)}
                className={`transition-colors duration-300 ${
                  currentSection === section.id
                    ? 'text-pink font-semibold'
                    : 'text-navy hover:text-pink'
                }`}
              >
                {section.label}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-navy"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => {
                  setCurrentSection(section.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`block w-full text-left py-2 transition-colors duration-300 ${
                  currentSection === section.id
                    ? 'text-pink font-semibold'
                    : 'text-navy hover:text-pink'
                }`}
              >
                {section.label}
              </button>
            ))}
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;