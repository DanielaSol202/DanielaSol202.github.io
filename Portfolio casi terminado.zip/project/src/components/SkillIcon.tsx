import React, { useState } from 'react';

interface SkillIconProps {
  name: string;
  icon: string;
  level: number;
}

const SkillIcon: React.FC<SkillIconProps> = ({ name, icon, level }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="relative group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="bg-white p-6 rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300 hover:scale-105 cursor-pointer">
        <div className="text-4xl mb-3 text-center">{icon}</div>
        <h3 className="text-navy font-semibold text-center text-sm">{name}</h3>
        
        {/* Skill Level Bar */}
        <div className="mt-3">
          <div className="w-full bg-beige rounded-full h-2">
            <div 
              className="bg-pink h-2 rounded-full transition-all duration-700 ease-out"
              style={{ 
                width: isHovered ? `${level}%` : '0%',
                transitionDelay: isHovered ? '0.2s' : '0s'
              }}
            />
          </div>
        </div>
      </div>
      
      {/* Tooltip */}
      {isHovered && (
        <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 bg-navy text-white px-3 py-1 rounded-lg text-xs whitespace-nowrap z-10">
          {level}%
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-navy"></div>
        </div>
      )}
    </div>
  );
};

export default SkillIcon;