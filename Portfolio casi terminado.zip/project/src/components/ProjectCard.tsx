import React, { useState } from 'react';
import { ExternalLink, Github } from 'lucide-react';

interface ProjectCardProps {
  title: string;
  description: string;
  technologies: string[];
  liveUrl?: string;
  githubUrl?: string;
  image: string;
}

const ProjectCard: React.FC<ProjectCardProps> = ({
  title,
  description,
  technologies,
  liveUrl,
  githubUrl,
  image
}) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="bg-white/70 backdrop-blur-sm rounded-3xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 hover:scale-105 group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-48 bg-gradient-to-br from-pink/20 to-navy/20 flex items-center justify-center">
        <div className="text-6xl">{image}</div>
        {isHovered && (
          <div className="absolute inset-0 bg-navy/80 flex items-center justify-center space-x-4 transition-all duration-300">
            {liveUrl && (
              <a
                href={liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-pink text-white p-3 rounded-full hover:bg-pink/80 transition-colors duration-300"
              >
                <ExternalLink size={20} />
              </a>
            )}
            {githubUrl && (
              <a
                href={githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white text-navy p-3 rounded-full hover:bg-beige transition-colors duration-300"
              >
                <Github size={20} />
              </a>
            )}
          </div>
        )}
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-navy mb-3">{title}</h3>
        <p className="text-navy/70 mb-4 text-sm leading-relaxed">{description}</p>
        
        <div className="flex flex-wrap gap-2">
          {technologies.map((tech, index) => (
            <span
              key={index}
              className="bg-pink/10 text-pink px-3 py-1 rounded-full text-xs font-medium"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;